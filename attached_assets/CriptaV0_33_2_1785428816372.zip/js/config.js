// Constantes de motor / render / combate. No dependen de los datos de nivel.

export const TILE = 56;        // píxeles por casilla A ZOOM 1x (tamaño base de referencia)
export const SIGHT = 6.5;      // radio de visión iluminada del héroe (antes 4.5, +2 casillas)
export const SIGHT_DIM = 15;  // más allá, hasta aquí se ve en penumbra (niebla); más lejos, negro sin explorar
export const CAMERA_MARGIN = 360; // margen extra (px) para que la cámara no se quede pegada al borde del mapa

// --- cámara / zoom ---
export const ZOOM_MIN = 0.6;   // más alejado
export const ZOOM_MAX = 2.2;   // más cercano
export const ZOOM_DEFAULT = 1.0;

// --- ficha del personaje (cenital puro): alto en fracción de casilla ---
export const TOKEN_TALL = 1.15;  // tamaño base de un personaje (enemigos, etc.)
export const HERO_TALL = 1.58;   // el héroe va grande: la cabeza asoma a la casilla de arriba (bajado un punto desde 1.70)
export const PROP_TALL = TOKEN_TALL / 2;  // objetos pequeños (lápidas...): mitad de una persona, sin salirse de su casilla

// --- economía de puntos de acción (PA), estilo Descent/BG3 ---
export const AP_MAX = 4;       // acciones por turno
export const MOVE_COST = 1;    // coste de moverse 1 casilla (llano o bajar)
export const CLIMB_COST = 2;   // coste extra de subir un escalón de altura
export const MAX_CLIMB = 1;    // diferencia de altura máxima cruzable (más = precipicio)
export const DIFFICULT_EXTRA = 1;  // coste extra por entrar en terreno difícil (matorrales, escombros...)
export const ATTACK_COST = 2;  // coste de atacar (depende del arma; por ahora fijo)

// Armadura estilo "valor numérico con rendimientos decrecientes" (como en WoW):
// % de daño físico reducido = armadura / (armadura + ARMOR_CONSTANT).
// Con ARMOR_CONSTANT=200: 25 de armadura -> ~11%, 100 -> 33%, 200 -> 50%, 400 -> 66%...
// nunca llega al 100%, cada punto extra reduce un poco menos que el anterior.
export const ARMOR_CONSTANT = 200;

// --- iniciativa (orden de turnos en combate) ---
// Cada tipo tiene un valor base; al entrar en combate se le suma una tirada de
// 1 a 6 (una sola vez por escaramuza, no cada ronda). El equipo del héroe podrá
// sumar un bonus aparte más adelante (hero.initiativeBonus, de momento en 0).
export const INITIATIVE_DIE = 6;
export const INITIATIVE_BASE = {
  hero: 8,
  enemy1: 6,   // esqueleto básico: lento
  enemy4: 9,   // arquero: rápido
  enemy5: 5,   // espectro: lento, pesado
  enemy6: 7,   // mago: medio
};
export const TURN_DELAY = 1000;  // ms de pausa entre el fin de un turno y el siguiente (héroe y NPCs)
export const COMBAT_ENTER_DELAY = 1000;  // ms de respiro al entrar en combate, antes de congelar el juego

// --- velocidad de juego (persistida) ---
// Afecta a la vez a: 1) las pausas entre turnos/acciones (TURN_DELAY, COMBAT_ENTER_DELAY
// y los ritmos de la IA enemiga), y 2) la propia animación de movimiento del héroe y los
// enemigos (antes esto último quedaba fijo siempre, por eso el ajuste apenas se notaba).
export const MOVE_STEP_BASE_MS = 170;   // duración por casilla a velocidad normal (héroe y enemigos)
const SPEED_MULT = { slow: 1.5, normal: 1, fast: 0.2 };
function loadGameSpeed() {
  try { const v = localStorage.getItem('cripta.enemySpeed'); return SPEED_MULT[v] ? v : 'normal'; }
  catch { return 'normal'; }
}
let gameSpeedKey = loadGameSpeed();
export function getGameSpeed() { return gameSpeedKey; }
export function setGameSpeed(v) {
  if (!SPEED_MULT[v]) return;
  gameSpeedKey = v;
  try { localStorage.setItem('cripta.enemySpeed', v); } catch {}
}
export function speedMult() { return SPEED_MULT[gameSpeedKey] || 1; }
// Duración real (ms) de un paso de movimiento a la velocidad actual. Con un
// mínimo de 60ms para que a velocidad "rápida" se vea fluido en vez de un salto.
export function moveDurationMs() { return Math.max(60, Math.round(MOVE_STEP_BASE_MS * speedMult())); }

// --- ajustes de comodidad (persistidos, apagados por defecto) --------------
// Autolootear: al tocar un cadáver/contenedor con botín pendiente, se coge
// todo de golpe (mismo resultado que el botón "coger todo") sin abrir la
// ventana de botín a esperar un toque más.
function loadBoolSetting(key) {
  try { return localStorage.getItem(key) === '1'; } catch { return false; }
}
function saveBoolSetting(key, v) {
  try { localStorage.setItem(key, v ? '1' : '0'); } catch {}
}
let autoLoot = loadBoolSetting('cripta.autoLoot');
export function getAutoLoot() { return autoLoot; }
export function setAutoLoot(v) { autoLoot = !!v; saveBoolSetting('cripta.autoLoot', autoLoot); }

// Autopasar turno con 0 PA en combate: al quedarte sin PA en pleno combate,
// el turno pasa solo (como ya pasa siempre fuera de combate) en vez de
// esperar a que toques "Fin de turno" a mano.
let autoSkipZeroAP = loadBoolSetting('cripta.autoSkipZeroAP');
export function getAutoSkipZeroAP() { return autoSkipZeroAP; }
export function setAutoSkipZeroAP(v) { autoSkipZeroAP = !!v; saveBoolSetting('cripta.autoSkipZeroAP', autoSkipZeroAP); }

// --- versión (fuente única; también se usa para el cache-busting de assets) ---
export const VERSION = '0.33.2';
